package com.posprinter.printdemo.utils

/**
 * @author: star
 * @date: 2022-07-25
 */
object Constant {
    const val EVENT_CONNECT_STATUS = "EVENT_CONNECT_STATUS"
}